tests for various CML input and output options:
1: CML1
2: CML2
a: use array format

run test.bat to run all tests

Peter MR, 2003-08-06

